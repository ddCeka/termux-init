#!/usr/bin/env python3
from setuptools import setup

def readme():
    with open('README.md') as f:
        return f.read()
setup(
    name='unrpyc',
    version='2.0.4',
    description='Tool to decompile Ren\'Py compiled .rpyc script files.',
    long_description=readme(),
    url='https://github.com/CensoredUsername/unrpyc',
    py_modules=['unrpyc', '.deobfuscate'],
    packages=['decompiler'],
    scripts=['unrpyc.py'],
    zip_safe=False,
)
